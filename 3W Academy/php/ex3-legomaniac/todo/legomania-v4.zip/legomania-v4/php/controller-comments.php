<?php

session_start();

include 'functions.php';
$link = get_db_link();


$livre = array();

$sql = "
	SELECT  
		`comments`.`name` ,  
		`comments`.`text` 

	FROM  `comments` 
";

$q = mysqli_query($link, $sql);

while ($data = mysqli_fetch_array($q, MYSQLI_ASSOC))
{
	$livre[] = array(
		'name' => ucfirst($data['name']),
		'text' => $data['text'],
	);
}