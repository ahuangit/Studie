<?php

include 'php/controller-show_comments.php';

// aucun affichage
