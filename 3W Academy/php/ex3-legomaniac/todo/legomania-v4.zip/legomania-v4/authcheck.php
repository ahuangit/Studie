<?php

include 'php/controller-authcheck.php';

// aucun affichage
