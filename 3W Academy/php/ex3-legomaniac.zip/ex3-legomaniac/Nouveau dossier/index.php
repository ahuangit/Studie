<!DOCTYPE html>

<html>
<head>
    <meta charset="utf-8">
    <link rel="stylesheet" type="text/css" href="reset.css">
    <link rel="stylesheet" type="text/css" href="style.css">

    <title>Lego Shop</title>
</head>
<body>

<div class="bgcolor">
<nav class="clearfix">
    <ul>
        <a href="#"><img src="img/logo.png" alt=""></a>
        <li><a href="#">Accueil </a></li>
        <li><a href="#">Nos produits</a></li>
        <li><a href="#">Contactez-nous</a></li>
    </ul>
</nav>

<div class="parent clearfix">
    <aside>                             <!-- SQL DES CATALOGUES -->
        <ul>
            <li><a href="#">cate 1</a></li>
            <li><a href="#">cateaaaaaaaaaaaa2</a></li>
            <li><a href="#">cate 3</a></li>
            <li><a href="#">cate aaaaaa4</a></li>
            <li><a href="#">cateaaaaa 5</a></li>
            <li><a href="#">cateaaaaaaaaa6</a></li>
        </ul>
    </aside>

    <article>                           <!-- FICHE DES PRODUITS-->
        <h2>CATEGORIES SELECTIONNE      <!-- SQL DU CATE SELECTIONNE-->
        <span class="hide">! ! BEAUCOUP DE CHOIX ! !</h2> 


        <table>
            <tr>
                <th>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
                quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
                consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
                cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
                proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</th>
                <th>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
                quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
                consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
                cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
                proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</th>
                <th>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
                quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
                consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
                cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
                proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</th>
            </tr>
        </table>
        <p>PAGE :   <a href="#">1</a>
                    <a href="#">2</a>
                    <a href="#">3</a>
                    <a href="#">4</a>
                    <a href="#">5</a>
                    <a href="#">6</a>
        </p>

    </article>

</div>

</div>
</body>
</html>
