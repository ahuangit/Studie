Objectifs
=======
- Comprendre comment PHP interagi avec la base de données
- Découverte du SQL
- La manipulation des tableau associatifs
- On sépare la logique métier (controller) de l'affichage (view)
