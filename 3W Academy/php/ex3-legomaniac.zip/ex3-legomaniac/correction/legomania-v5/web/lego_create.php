<?php

$object = 'lego';
$action = 'create';

include '../init.php';
