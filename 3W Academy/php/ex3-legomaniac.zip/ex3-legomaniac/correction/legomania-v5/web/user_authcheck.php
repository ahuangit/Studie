<?php

$object = 'user';
$action = 'authcheck';

include '../init.php';
