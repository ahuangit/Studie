<?php

$object = 'lego';
$action = 'edit';

include '../init.php';
