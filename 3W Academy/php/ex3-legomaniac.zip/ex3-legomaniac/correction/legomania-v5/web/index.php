<?php

header("Location: lego_index.php");