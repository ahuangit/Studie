<?php

$object = 'lego';
$action = 'show';

include '../init.php';
