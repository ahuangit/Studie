<?php

$object = 'comment';
$action = 'create';

include '../init.php';
