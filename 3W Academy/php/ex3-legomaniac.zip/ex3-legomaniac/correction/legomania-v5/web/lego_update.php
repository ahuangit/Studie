<?php

$object = 'lego';
$action = 'update';

include '../init.php';
