<?php

$object = 'lego';
$action = 'new';

include '../init.php';
