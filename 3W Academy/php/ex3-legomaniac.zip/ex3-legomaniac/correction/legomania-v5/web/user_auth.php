<?php

$object = 'user';
$action = 'auth';

include '../init.php';
