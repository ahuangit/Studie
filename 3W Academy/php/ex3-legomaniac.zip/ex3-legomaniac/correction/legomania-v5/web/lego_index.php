<?php

$object = 'lego';
$action = 'index';

include '../init.php';
