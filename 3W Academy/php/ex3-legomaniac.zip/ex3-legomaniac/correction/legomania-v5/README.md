Objectifs
=======
- Création d'un système de commentaires
- Refactorer proprement son code