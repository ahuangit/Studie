<?php

header("Location: web/lego_index.php");