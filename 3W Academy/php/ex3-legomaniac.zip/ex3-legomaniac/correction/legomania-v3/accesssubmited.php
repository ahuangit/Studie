<?php

include 'php/controller-accesssubmited.php';

// aucun affichage
