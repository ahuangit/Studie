Objectifs
=======
- Assimilation des notions vues précédement
- Factorisation du code (avec les include)
- Comment on lie des pages entre-elles en passant de paramètres en GET
- Astuce: La pagination