<?php include 'php/controller-access.php'; ?>

<?php include 'header.html'; ?>
<a href="index.php">Page d'accueil</a>
<p> hello </p>