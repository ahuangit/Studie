<?php

include 'php/controller-commentscheck.php';

// aucun affichage
