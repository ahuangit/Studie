Objectifs
=======
- Création d'une authentification simple par mot de passe
- Manipulation des Sessions