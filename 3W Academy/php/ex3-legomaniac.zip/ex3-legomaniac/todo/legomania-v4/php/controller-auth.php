<?php

session_start();

include 'functions.php';
