<?php

include 'php/auth.php';

// aucun affichage
